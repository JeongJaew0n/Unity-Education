using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;

public class SpaceShip : MonoBehaviourPun
{
    public float rotationSpeed = 90f;
    public float moveSpeed = 2.0f;
    public float maxSpeed = 0.2f;

    public GameObject bulletPrefab;

    private new Rigidbody rigidbody;

    private float rotation = 0.0f;
    private float accacceleration = 0.0f;   // ���ӵ�
    private float shootingTimer = 0.0f;

    private float shootingInterval;

    private float lag;

    private float timer = 0f;

    private void Awake()
    {
        rigidbody = GetComponent<Rigidbody>();
    }

    private void Update()
    {
        if (!photonView.IsMine)
        {
            return;
        }

        rotation = Input.GetAxis("Horizontal");
        accacceleration = Input.GetAxisRaw("Vertical");

        timer += Time.deltaTime;
        if (Input.GetKeyDown(KeyCode.Space) && timer >= shootingInterval)
        {
            shootingTimer = 0.0f;
            photonView.RPC("Fire", RpcTarget.AllViaServer, rigidbody.position, rigidbody.rotation);

        }


    }

    private void FixedUpdate()
    {
        if (!photonView.IsMine)
        {
            return;
        }
        float y = rotation * rotationSpeed * Time.fixedDeltaTime;   // fixedDeltaTime�� FixedUpdate���� ����ϴ°� �´�!
        Quaternion rot = rigidbody.rotation * Quaternion.Euler(0f,y,0f);
        rigidbody.MoveRotation(rot);

        Vector3 force = (rot * Vector3.forward) * accacceleration * 1000f * moveSpeed * Time.fixedDeltaTime;
        rigidbody.AddForce(force);
        if (rigidbody.velocity.magnitude > (maxSpeed * 1000f))
        {
            rigidbody.velocity = rigidbody.velocity.normalized * maxSpeed * 1000f;
        }
        CheckExitScreen();
    }

    private void CheckExitScreen()
    {
        if (Camera.main == null)
            return;

        Debug.Log("Z������: " + Camera.main.orthographicSize);

        if (Mathf.Abs(rigidbody.position.x) > (Camera.main.orthographicSize))
        {
            /* �̰� ���� �غ���. */
            rigidbody.position = new Vector3(-Mathf.Sign(rigidbody.position.x), rigidbody.position.y, rigidbody.position.z * Camera.main.orthographicSize);

            rigidbody.position -= rigidbody.position.normalized * 0.1f;
        }

        if (Mathf.Abs(rigidbody.position.z) > (Camera.main.orthographicSize))
        {
            /* �̰� ���� �غ���. */
            rigidbody.position = new Vector3(rigidbody.position.x, rigidbody.position.y, -Mathf.Sign(rigidbody.position.z)*Camera.main.orthographicSize);

            rigidbody.position -= rigidbody.position.normalized * 0.1f;
        }
    }

    [PunRPC]
    public void Fire(Vector3 position, Quaternion rotation, PhotonMessageInfo info)
    {
        float flag = (float)(PhotonNetwork.Time - info.timestamp);
        GameObject bullet;
        bullet = Instantiate(bulletPrefab, rigidbody.position, Quaternion.identity);
        bullet.GetComponent<Bullet>().InitializeBullet(photonView.Owner, rotation * Vector3.forward, Mathf.Abs(lag));
    }
}
