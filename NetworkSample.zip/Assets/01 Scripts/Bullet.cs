using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Realtime;

public class Bullet : MonoBehaviour
{
    public Player owner
    {
        get;
        private set;
    }

    private void Start()
    {
        Destroy(gameObject, 3f);        // �Ѿ��� �����ǰ� 3�� �� �˾Ƽ� �����
    }

    private void OnCollisionEnter(Collision collision)
    {
        Destroy(gameObject);       // �ε����� �����
    }

    public void InitializeBullet(Player owner, Vector3 dir, float lag)
    {
        this.owner = owner;
        transform.forward = dir;

        Rigidbody rigidbody = GetComponent<Rigidbody>();
        rigidbody.velocity = dir * 200f;
        rigidbody.position += rigidbody.velocity * lag;
    }
}
