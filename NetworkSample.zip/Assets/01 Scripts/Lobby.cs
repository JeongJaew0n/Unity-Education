using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;

public class Lobby : MonoBehaviourPunCallbacks
{
    public GameObject roomPanel;
    private void Awake()
    {
        gameObject.SetActive(false);
    }

    public void OnJoinRamdomRoomButtonClick()
    {
        PhotonNetwork.JoinRandomRoom();
    }

    public override void OnJoinRandomFailed(short returnCode, string message)
    {
        string roomName = "Room " + Random.Range(1000, 9999);
        RoomOptions options = new RoomOptions { MaxPlayers = 8 };
        PhotonNetwork.CreateRoom(roomName, options, null);
        Debug.Log("Create Room " + roomName);

    }

    public override void OnJoinedRoom()
    {
        Debug.Log("OnJoinedRoom");
        gameObject.SetActive(false);

        if(PhotonNetwork.IsMasterClient)
            roomPanel.SetActive(true);

    }

}
